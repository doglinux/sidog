#!/bin/bash

#if [ ! -d /run/user/$(id -u) ]; then
#	export XDG_RUNTIME_DIR=/tmp/runtime-${USER}
#	if [ ! -d ${XDG_RUNTIME_DIR} ] ; then
#	mkdir -p ${XDG_RUNTIME_DIR}
#	chmod 0700 ${XDG_RUNTIME_DIR}
#	chown ${USER} ${XDG_RUNTIME_DIR}
#	fi
#fi

if [ $(id -u) = 0 ]; then
SPOT_HOME=$(awk -F: '$1=="puppy" {print $6}' /etc/passwd)
if [ -n "$SPOT_HOME" ]; then
XUSER=puppy
else   # use user guest
XUSER=guest
fi
#export XDG_RUNTIME_DIR=/run/user/0
#mkdir -p ${XDG_RUNTIME_DIR}
#	chmod 0700 ${XDG_RUNTIME_DIR}
#	chown ${USER} ${XDG_RUNTIME_DIR}
IDU=$(id -u ${XUSER}) 
[ -f /tmp/_rau ] && export PULSE_SERVER=unix:/run/user/${IDU}/pulse/native || export PULSE_SERVER=unix:/tmp/runtime-${XUSER}/pulse/native
 export PULSE_COOKIE=/home/${XUSER}/.config/pulse/cookie
fi

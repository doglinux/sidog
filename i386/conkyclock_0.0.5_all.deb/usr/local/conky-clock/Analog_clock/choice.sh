#!/bin/bash
# echo $[($RANDOM % ($[200 - 100] + 1)) + 100]
min=1
max=69
no=$[($RANDOM % ($[$max - $min] + 1)) + $min]
NUM=$(echo -n $no | wc -c)
[ "$NUM" -lt 2 ] && no=0${no} 
cp ~/.conky/Analog_clock/theme/clock_face${no}.png ~/.conky/Analog_clock/theme/clock_face.png
exit

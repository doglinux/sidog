if (get_window_name()=="xlunch: Graphical app launcher") then
undecorate_window();
end 
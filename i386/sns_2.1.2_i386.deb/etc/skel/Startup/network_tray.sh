#!/bin/sh
exec /opt/bin/network_tray

